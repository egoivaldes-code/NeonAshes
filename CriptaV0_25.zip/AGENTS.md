# AGENTS.md — guía rápida para trabajar en Cripta

Este archivo es para que cualquier IA (o persona) que abra este proyecto por
primera vez entienda rápido cómo está montado, sin tener que releer todo el
código. Si cambias algo estructural (arquitectura, convenciones, herramientas
nuevas), actualiza también este archivo.

## ⚠️ Protocolo anti-desincronización (léelo primero, en serio)

El usuario a veces trabaja el mismo proyecto en **varios chats en paralelo**.
Ya ha pasado una vez que dos chats avanzaran versiones distintas desde el
mismo punto (uno hizo 0.7.1→0.7.3 con el cementerio y la altura relativa;
otro hizo 0.8→0.9 con el héroe a escena y la interfaz movible) sin que
ninguno de los dos supiera del otro, y hubo que fusionar a mano.

Para no repetirlo:

1. **Al empezar a trabajar en una versión nueva, pregunta primero si esta es
   la última realmente subida al repo**, sobre todo si el usuario lleva un
   rato sin mandar un zip nuevo o si retoma la conversación tras una pausa
   larga. Un simple "¿esto sigue siendo lo último o has tocado algo en otro
   chat?" ahorra mucho lío.
2. **Si el usuario sube un zip nuevo diciendo "vamos por la X.X"**, trátalo
   como la fuente de verdad: compara con lo que tengas en local (`diff -rq`),
   identifica qué cambió, y fusiona explícitamente lo que solo exista en tu
   copia hacia esa base nueva. No asumas que tu copia estaba al día.
3. **Este archivo (`AGENTS.md`) y `CHANGELOG.md` son el punto de partida
   seguro.** Si te incorporas a este proyecto sin más contexto, léelos
   enteros antes de tocar nada. Mantenlos actualizados según avances: si
   creas una herramienta, una convención o una protección nueva, se anota
   aquí en el mismo turno en que la creas, no "para luego".
4. Después de fusionar o de cualquier cambio de bulto, **corre la batería de
   pruebas de conectividad/solapes** (ver más abajo) sobre el resultado final
   antes de empaquetar, aunque ya la hubieras corrido antes en una rama
   distinta.

## Qué es esto

Cripta es un juego de rol táctico cenital (rejilla, estilo Descent 2), con
eventos de decisión en HTML, para **móvil y PC**, **multiidioma** (es/en).
Web estática (HTML/CSS/JS con **módulos ES nativos, sin build step**),
alojada en GitHub Pages (`egoivaldes-code/cripta`). El usuario trabaja desde
el móvil, no programa, y no conoce jerga técnica — cualquier explicación va
en español llano.

De cara al futuro: la idea es que compilarlo a app (Capacitor/Electron,
.apk/.exe) sea solo cambiar el "launcher" alrededor y pegar estos mismos
archivos, sin tocar el juego en sí. Por eso: **rutas siempre relativas**,
nunca nada atado a un dominio o a GitHub Pages, y toda la carga de datos vía
`fetch()`/`import` normal (nada de asumir `file://`).

## El editor de niveles (herramienta aparte, fuera del juego)

Existe un archivo HTML independiente (`cripta_editor_niveles.html`, generado
por Claude, NO vive en el repo del juego) que el usuario abre en su móvil
para preparar niveles sin escribir código. No es parte del juego: es un
artifact que se regenera cada vez que hace falta ampliarlo.

**Qué hace:**
- Pinta terreno sobre la imagen real de un mapa (transitable / obstáculo /
  elevado / difícil), casilla a casilla.
- Coloca/quita héroe, enemigos (con desplegable de tipo), y objetos (tumba,
  cofre, altar, palanca, orbe, mesa, ítem, trampa, entrada/salida).
- Permite subir mapas nuevos (calcula sola la rejilla a partir de una celda
  "cómoda", sin depender de que el tamaño de casilla encaje exacto en píxeles).
- Todo se guarda solo (persistent storage del artifact), incluidos los mapas
  subidos.
- Lee `data/manifest.json` **en directo** desde la web publicada
  (`egoivaldes-code.github.io/cripta/data/manifest.json`) para saber qué
  enemigos/objetos existen en la versión actual, con una copia de respaldo
  embebida por si no hay conexión. Así, cuando se añade un monstruo u objeto
  nuevo al juego, solo hay que actualizar ese único archivo — no hay que
  regenerar la herramienta entera cada vez.

**Flujo de trabajo:**
1. El usuario pinta/coloca en la herramienta.
2. Pulsa "Exportar" → "Copiar JSON" → pega el resultado en el chat.
3. Claude convierte ese JSON (`grid` + `entities`) al formato real de
   `data/levels/<nombre>.json` (tiles/elev/difficult/background/start.hero/
   start.foes/triggers/exit), y **siempre** corre la batería de pruebas de
   conectividad antes de dar nada por bueno (ver más abajo).

**Numeración de entidades**: cada objeto colocado por duplicado (cofre,
evento, tumba, entrada, salida...) se numera solo en el propio mapa y en el
JSON exportado (`Cofre 1`, `Cofre 2`...), calculado por orden de colocación
dentro de su mismo tipo (y subtipo, en el caso de los enemigos). El héroe no
se numera (siempre hay uno). Entrada y Salida son herramientas separadas y
ambas admiten varias unidades — desde la V0.19 el motor real también soporta
**varias salidas por nivel** (`state.exits[]`, formato "mueble": ocupa su
casilla, se interactúa desde al lado, opcionalmente `blocked`), además del
formato antiguo de una sola salida (`level.exit`, que Cripta/Mausoleo1/
Mausoleo2/level2 siguen usando sin problema — el motor acepta los dos).

**Objetos sin evento conectado**: el motor real (`rules.js`) comprueba si
existe `state.events[tr.id]` antes de abrir la tarjeta; si un objeto (p.ej.
un "Evento" recién colocado, o un cofre al que aún no le has puesto datos en
`events.json`) no tiene nada conectado, se muestra un mensaje neutro y no
pasa nada más — no revienta el juego. Ten esto en cuenta al añadir objetos
nuevos desde el editor: colócalos primero, pruébalos si quieres, y dile a
Claude qué debe pasar en cada uno cuando quieras conectarlos de verdad.

**Objetos que no bloquean y se disparan solos (`walkTrigger`)**: por defecto,
cualquier trigger que no sea una trampa bloquea su casilla (hay que
interactuar desde al lado). Si un trigger concreto lleva `walkTrigger:true`
en el nivel, se comporta como una trampa (no bloquea, se activa solo al
pisarlo) pero sin el mecanismo de daño/desarme — el efecto lo decide
`triggerWalkEvent()` en `rules.js` según `state.events[tr.id].type`. Se usa
para eventos de ambientación (tarjeta con imagen + texto, sin opciones, se
cierra al tocarla — ver `openStoryCard`/`renderStoryCard` en `ui.js`), pero
sirve para cualquier cosa que deba dispararse sola al pasar por encima.

**Protecciones importantes descubiertas al construirla** (aplican a
cualquier artifact HTML que se construya para este proyecto):
- **`prompt()`, `confirm()` y `alert()` nativos del navegador NO funcionan**
  dentro del entorno donde corren los artifacts (sandboxed iframe, sin
  `allow-modals`). Si necesitas pedir texto o confirmar algo, hay que
  construir un modal propio con HTML/CSS/JS (ver `#modalBack`/`#modalBox` en
  la herramienta como referencia). Un `prompt()` ahí simplemente no hace
  nada — no falla con un error visible, así que este bug puede pasar
  desapercibido si no se prueba explícitamente esa función.
- **Pintar/tocar vs arrastrar cámara**: si un `pointerdown` dispara la acción
  inmediatamente, el primer toque de cualquier intento de arrastre se
  interpreta como pintura. Solución: no actuar hasta `pointerup`, y solo si
  el movimiento desde el `pointerdown` fue menor a un umbral; si se superó,
  se entiende que el usuario quería mover la cámara, no pintar. **Ojo con el
  valor del umbral**: empezó en 10px, pero un toque real con el dedo casi
  siempre tiembla más que eso — con 10px, el editor interpretaba tocar como
  arrastrar y no colocaba nada, sin avisar (no es un error visible, así que
  pasa desapercibido si no se prueba tocando de verdad en un móvil). Subido
  a 20px en la v0.12.4.
- **Layout en móvil**: mejor un `body` en columna flex a pantalla completa
  (`height:100dvh`) con las barras como `flex:none` y el área de mapa como
  `flex:1`, que calcular alturas fijas a mano — se adapta solo si cambia el
  contenido de las barras.

## Novedades del editor (hasta v0.12.6) y del motor (V0.22)

**Editor — mapas incluidos protegidos**: Cementerio, Mausoleo 1 y Mausoleo 2
ahora viven "horneados" dentro del propio archivo HTML (`MAPS.cemetery`,
`MAPS.mausoleo1`, `MAPS.mausoleo2`), no solo en el almacenamiento del
artifact. Esto evita que desaparezcan si Android separa el guardado entre
archivos HTML distintos (ya pasó una vez con Mausoleo 1 y 2). El botón de
borrar mapa está bloqueado para cualquier mapa `builtin:true`, sin excepción,
aunque también sea `custom:true` (necesario para poder calibrar su rejilla).

**Editor — sincronizar desde el juego publicado**: botón "🔄 Actualizar" por
mapa, que descarga `data/levels/<nombre>.json` en vivo y sustituye terreno/
enemigos/objetos/salidas, conservando notas y eventos extra que solo existan
en el editor. Comprueba que `cols`/`rows` coincidan antes de sobrescribir
nada. Útil para refrescar un mapa builtin tras cambios hechos a mano en el
repo (como el recorte de columnas de Mausoleo 2, ver más abajo).

**Editor — `allowDuplicateId`**: el editor exige normalmente IDs únicos por
marcador (`ensureEntityIds` renombra en solitario cualquier duplicado). La
emboscada de Mausoleo 2 necesita justo lo contrario: sus dos puntos
comparten literalmente el mismo id (`mausoleo2_ambush`) a propósito, para que
activar cualquiera de los dos marque ambos como usados. Un trigger/entidad
con `allowDuplicateId: true` queda exento de ese renombrado automático y de
la validación de "ID duplicado" al exportar. Si se añade en el futuro otro
mecanismo con el mismo patrón (un id compartido entre varios marcadores),
usar este mismo campo en vez de inventar otro.

**Editor — calibración de rejilla (`_editorMap`)**: en mapas propios
(`custom:true`), el editor deja ajustar tamaño de celda y desfase X/Y de la
rejilla sobre la imagen real (nudge + botones +/-). Al exportar, si el mapa
tiene calibración, se incluye `_editorMap: {image, width, height, cols, rows,
cellSize, originX, originY}` en el JSON. **Ojo**: los botones de tamaño de
celda recalculan `cols`/`rows` a partir de `w/cellPx` y recortan/rellenan la
rejilla — si se reduce una columna/fila que tenía marcadores, se pierden
(avisa cuántos). Revisar siempre que las dimensiones resultantes sigan
coincidiendo con lo que se quiere publicar antes de pegar el JSON en el
juego.

**Motor — el fondo pintado ya respeta `_editorMap`** (`state.js`/
`render.js`): antes, el motor SIEMPRE estiraba la imagen de fondo completa
para llenar exactamente `cols*TILE × rows*TILE`, dando por hecho que la
imagen, de borde a borde, encajaba con la rejilla sin márgenes. Si el nivel
trae `_editorMap`, ahora se recorta exactamente esa región de la imagen
(`originX, originY, cellSize*cols, cellSize*rows`) antes de estirarla sobre
la rejilla — el mismo recorte que ve el usuario en el editor. Si un nivel no
trae `_editorMap` (los de siempre), se comporta exactamente igual que antes
(compatible hacia atrás). Mausoleo 2 es el primer nivel con esta calibración
real; si el desfase queda ligeramente fuera de los bordes de la imagen
(`originX`/`originY` negativos, o `cellSize*rows` mayor que el alto real),
el canvas simplemente recorta esa parte y se ve un hueco vacío ahí — no
revienta, pero puede notarse visualmente y merece un repaso fino.

**Motor — velocidad de juego centralizada en `config.js`**: `getGameSpeed`/
`setGameSpeed`/`speedMult`/`moveDurationMs` viven en `config.js` (antes el
multiplicador vivía solo dentro de `rules.js` y solo afectaba a las pausas
de la IA, nunca a la animación de movimiento en sí). `anim.js` y `rules.js`
importan estas funciones desde `config.js` para no crear un import
circular entre ellos. `rules.js` sigue exportando `getEnemySpeed`/
`setEnemySpeed` (usadas por `main.js`) como wrappers finos sobre las de
`config.js`, para no tener que tocar `main.js`. Multiplicadores actuales:
`slow: 1.5, normal: 1, fast: 0.2`, con `moveDurationMs()` puesto a un mínimo
de 60ms para que la velocidad rápida no se vea como un salto roto.

**Motor — patrón de "tarjeta cómic con opciones" para mecanismos** (`ui.js`:
`renderLeverCard`, css: `.card.story .storychoices`): mismo molde visual que
la tarjeta narrativa (`openStoryCard`/`.card.story`), pero con kicker/título/
pregunta y botones Sí/No en el hueco de pergamino en vez de solo texto. Se
activa automáticamente si el evento del mecanismo trae `image` (clave
registrada en `assets.js`); si no la trae, sigue funcionando con el menú de
texto plano de siempre — no hace falta tocar el motor para futuras palancas
sin arte todavía, solo añadir `image` en `events.json` cuando la tengan. El
recuadro de texto/opciones se posiciona a mano por porcentajes sobre la
imagen (pensado para ilustraciones con la escena a la izquierda y hueco de
pergamino en blanco a la derecha, como las de ambientación) — si la próxima
imagen tiene el hueco en otro sitio, hay que reajustar esos porcentajes a
ojo (o medir con Python/PIL dónde termina el dibujo, como se hizo para la
palanca del cementerio).

## Protocolo de pruebas antes de empaquetar (obligatorio)

Antes de dar cualquier cambio de nivel, mapa o lógica de juego por bueno,
verificar con un script de Node (no hace falta navegador para esto) copiando
el módulo relevante y quitando los `?v=X.X` de los imports:

- **Cualquier nivel nuevo o editado**: héroe/enemigos/trampas/salida no caen
  en un muro, no se solapan entre sí, y son alcanzables desde el punto de
  partida (BFS/Dijkstra con las reglas reales de `stepNeighbors`, no un BFS
  ingenuo — la regla de no cortar esquinas en diagonal puede dejar rincones
  inalcanzables que un BFS simple no detectaría).
- **Cambios en `anim.js`**: probar el ciclo completo de cada animación
  (idle en bucle, transición de postura, ataque que vuelve solo a idle,
  golpe que interrumpe correctamente otra acción en curso, muerte que se
  congela para siempre) usando el reloj real (`performance.now()`), no
  marcas de tiempo inventadas — desincronizan el test consigo mismo.
- **Cambios de movimiento/altura**: verificar que subir cuesta más PA, que
  un desnivel de sobra bloquea, y que la diagonal no corta esquinas.
- Repetir la batería completa (no solo el test nuevo) tras cualquier fusión
  entre versiones divergentes, como recuerda el protocolo anti-desincronización.

## Mapa de módulos (`js/`)

Cada archivo tiene una responsabilidad única. Antes de tocar algo, mira aquí
qué módulo le corresponde:

| Archivo | Responsabilidad |
|---|---|
| `config.js` | Constantes: tamaño de casilla, zoom, PA, escala de personajes, **VERSION** (fuente única). |
| `i18n.js` | Carga `data/i18n/<lang>.json` y traduce por clave con `t()`. |
| `assets.js` | Precarga de imágenes y hojas de animación. |
| `state.js` | Estado de la partida, mapa, altura, terreno difícil, niebla de guerra, alcance (Dijkstra). No dibuja ni toca el DOM. |
| `anim.js` | Motor de animación: posición visual por actor, separado de la lógica. Dos sistemas conviven (ver abajo). |
| `render.js` | Todo el dibujo en Canvas: cámara, zoom, tiles, bordes de altura, actores. Es la ÚNICA parte atada al canvas. |
| `rules.js` | Turnos, combate, interacción, IA enemiga. Agnóstico del dibujo. |
| `ui.js` | HUD, cartas de evento, ajustes, fin de partida. Todo el texto pasa por `t()`. |
| `mapgen.js` | Ensamblador de losetas tipo Descent para mapas **aleatorios**. Probado pero sin usar en ningún nivel activo (reserva para el futuro). |
| `main.js` | Punto de entrada: carga idioma/datos, cablea módulos, arranca el bucle. |
| `skills.js` | Tienda de habilidades (SISTEMA TEMPORAL de pruebas, ver sección propia más abajo) + barra de acción. Mismo patrón que `inventory.js`: datos + estado + render + interacción en un solo módulo autocontenido. |
| `savegame.js` | Guardado/resume de partida (ver sección propia) + oro persistido. No dibuja ni toca el DOM. |

Datos en `data/`: `events.json` (objetos/eventos), `i18n/es.json` y
`en.json` (todo el texto del juego), `levels/*.json` (mapas), `manifest.json`
(monstruos/objetos disponibles en esta versión, lo lee el editor de niveles
en directo) y `changelog.json` (notas de versión para la pantalla de
novedades al arrancar — distinto del `CHANGELOG.md` de la raíz, que es para
desarrollo).

## Convenciones que hay que respetar siempre

- **Nunca texto hardcodeado.** Todo lo que vea el jugador va en
  `data/i18n/es.json` **y** `en.json`, con la misma clave en los dos. Se
  traduce con `t('clave', {params})`.
- **La versión vive en un único sitio**: `VERSION` en `js/config.js`. De ahí
  sale el `?v=X.X.X` que se añade a todos los `import`, `fetch()` e imágenes,
  para que el navegador no sirva versiones viejas cacheadas.
  **No lo edites a mano**: usa `tools/bump_version.py` (ver más abajo).
- **Esquema de versión**: `V0.XX` para cambios grandes, `V0.XX.X` para
  parches/fixes pequeños. Cada entrega es un `.zip` completo
  (`CriptaV0.XX.zip`) que sustituye entero al proyecto anterior.
- Cada entrega al usuario incluye, aparte del zip: un prompt de Replit
  (que SIEMPRE debe decir explícitamente que descomprima el zip sustituyendo
  los archivos existentes) y un prompt de Jules, copiables enteros por
  separado, y el prompt de Replit debe terminar con el mensaje de commit de
  esa versión.
- **Siempre preguntar antes de empaquetar** el zip final, por si se quiere
  meter algo más en la misma versión.

## El sistema de animación (`anim.js`)

Conviven dos sistemas mientras se migra el arte poco a poco:

- **"legacy"**: el de siempre, una hoja de 4 fotogramas fijos (quieto, paso
  dcha/izq, ataque). Lo siguen usando los tipos que no aparecen en
  `ANIM_CLIPS`.
- **"animado"**: personajes con animaciones de verdad por nombre (`idle`,
  `walk`, `attack`, `death`, etc.), cada una con su número de fotogramas y
  velocidad, definidas en `ANIM_CLIPS`. El héroe además tiene dos idles
  (paz/combate) que cambian solas según haya un enemigo cerca.

Para saber si un tipo de sprite usa animaciones de verdad, mira si aparece
como clave en `ANIM_CLIPS` (en `anim.js`).

**Objetos con animación propia (no personajes)**: el mismo sistema sirve para
props como el cofre (`idle`=cerrado, `open`=se abre y se queda abierto para
siempre). Se usa `anim.openProp(nombre, tipo)` en vez de `anim.die()`, con el
mismo patrón de "se congela en el último fotograma para siempre" (`a.opened`,
paralelo a `a.dying`). El nombre del actor para un objeto de mapa es
`` `prop:${x}:${y}` `` (estable mientras el objeto no se mueva de casilla).
`render.js` dibuja el objeto igual que a un personaje (resolviendo por
`anim.resolve`) si su sprite tiene clips; si es una imagen suelta (tumba,
cripta), sigue el camino estático de siempre.

**Corrección de orientación nativa**: no todo el arte viene dibujado mirando
hacia la derecha por defecto (la convención que asume el resto del código al
decidir hacia dónde debe mirar un personaje). Si un personaje queda mirando
siempre al lado contrario del que debería, antes de tocar la lógica de
`facing`, comprueba si el ARTE en sí mira a la izquierda de serie — en ese
caso, el arreglo es añadir una entrada a `NATIVE_FACING` en `render.js`
(no tocar `anim.js`, que calcula la dirección "lógica" correctamente; el
problema está solo en cómo se traduce esa dirección al volteo del dibujo).

## Técnica: procesar hojas de animación nuevas (Nano Banana → juego)

El usuario genera arte con Nano Banana (fondo magenta `#FF00FF`, varias poses
en fila). Antes de meterlo al juego, el proceso que ha demostrado ser fiable:

1. **Quitar el magenta** por color (no por transparencia, Nano Banana no la
   da): `r>140 and b>70 and g<115 and (r-g)>55`.
2. **Nunca recortar por ancho igual** (`i*ancho/N`). Las espadas, capas y
   miembros de una pose casi siempre invaden el hueco del vecino, y un corte
   recto se lleva un trozo ajeno o dispersa el propio. En su lugar, **recortar
   por pieza conectada** (`scipy.ndimage.label`): cada figura es su propia
   isla de píxeles. Si el nº de piezas detectadas no coincide con el nº de
   poses esperado, casi siempre es porque dos piezas se tocan (un cruce de
   espadas) — separar visualmente esos casos a mano si hace falta.
3. **Enmascarar, no solo recortar el rectángulo**: al recortar la caja de una
   pieza, poner a transparente cualquier píxel de la caja que pertenezca a
   OTRA etiqueta (puede haber solape de cajas aunque las piezas no se toquen).
4. **Una sola escala para todo el personaje**, nunca "ajustar cada fotograma
   a la misma altura de destino". Si se hace lo segundo, agacharse/alzar la
   espada por encima de la cabeza *cambia el tamaño aparente* del personaje
   entre fotogramas (la pose más alta se ve "más pequeña" al forzarla al
   mismo alto). Se mide la altura del cuerpo en una pose neutral (p.ej. el
   primer fotograma del idle) UNA vez, y esa misma escala se aplica a todos
   los fotogramas de todas las animaciones de ese personaje.
5. Animaciones especiales en 2 filas (p.ej. una secuencia de muerte con
   "de pie" arriba y "tumbado" abajo): la frontera real entre filas casi
   nunca es exactamente la mitad del alto de la imagen; buscarla por la
   franja de filas con cobertura de píxeles ≈0 más cercana a la mitad.
6. Verificación automática antes de mirar nada a ojo: ningún fotograma con
   cobertura de píxeles casi nula (recorte vacío) ni que toque el borde del
   lienzo de 128×128 (indicio de recorte real, salvo que sea justo el borde
   exacto sin perder píxeles — comprobar visualmente ese caso límite).

## Técnica: arreglar sprites que "tiemblan"

Si un personaje oscila de lado a lado durante una animación en bucle (sobre
todo el idle), casi siempre es porque los fotogramas de esa hoja no están
recortados en el mismo sitio dentro de su celda (el centro del personaje
varía de una columna a otra). Se diagnostica y arregla así:

```
python3 tools/recenter_sprite.py assets/sprites/TIPO/CLIP.png --frames N --dry-run
```

Eso enseña el centro (`cx`) y la base (`bottom`) de cada fotograma. Si varían
entre fotogramas que deberían estar alineados, quita `--dry-run` para
recentrar de verdad (ver `tools/recenter_sprite.py` para más opciones, como
`--vertical` si además hay que alinear la base).

**Ojo con centrar por el CUERPO ENTERO cuando hay un arma o un brazo que se
mueve.** Si el personaje sostiene algo (espada, escudo) que se balancea de
un lado a otro entre fotogramas, el centro de la caja del cuerpo ENTERO
puede salir "centrado" de casualidad porque el arma compensa el desplazamiento
real del torso/cabeza — y aun así se ve temblar, porque lo que el ojo
sigue es la cabeza, no el promedio de toda la silueta. Si el arreglo de arriba
no elimina el temblor del todo, mide el centro de solo la CABEZA (la franja
superior del contenido, no toda la caja) fotograma a fotograma, y recentra
por ahí en su lugar. Además: este truco falla en poses que cambian mucho de
postura dentro del mismo clip (una embestida, una caída) — ahí "la cabeza"
puede no ser detectable de forma fiable con una franja fija, y forzar un
recentrado agresivo puede cortar contenido por el borde. Comprueba siempre
cobertura de píxeles y bordes tras recentrar (como en el resto de la hoja) y,
si un fotograma sale mal, mejor no tocarlo que arriesgarse a romperlo.

## Técnica: que los turnos de la IA no parezcan instantáneos

Si una función de turno de enemigo hace varias acciones seguidas (moverse
varias veces, acercarse y atacar) todas en la misma función síncrona, cada
`anim.move()`/`anim.attack()` **pisa** la animación anterior antes de que el
siguiente fotograma llegue a pintarla — visualmente parece que todo pasa
de golpe. La solución es hacer la función de turno `async` y meter un
`await sleep(ms)` entre acción y acción (ver `enemyAITurn` en `rules.js`),
con un flag tipo `aiTurnActive` que bloquee los toques del jugador mientras
tanto (además de los ya existentes `state.busy`/`anim.active()`).

## Referencia de diseño: la IA de movimiento de Descent (Viaje a las Tinieblas)

Descent: Journeys in the Dark (2ª edición) y su app-compañera Road to Legend
(la que hace de "game master" automático) llevan más de una década puliendo
reglas de movimiento e IA para un dungeon crawler por turnos y casillas —
muy parecido a lo que es Cripta. Antes de inventar una regla de movimiento
nueva desde cero, merece la pena mirar aquí primero. Fuente principal: la
Community Rules Reference Guide (CRRG) de Descent 2E, sección "Movement",
"Engage", "Direction" y "Retreat" (descent-community.org).

**Ideas ya adoptadas en Cripta:**

- **"Engage"**: un enemigo que se acerca simplemente pathea hacia el
  objetivo y se para en cuanto queda adyacente o se le acaba el PA. Es
  literalmente `approachStep()` en `rules.js`.
- **Regla de "Toward"**: al acercarse, una figura puede alejarse *un
  momento* del objetivo si el resultado final la deja más cerca (rodear un
  muro). Por eso `approachStep`/`findPath` usan Dijkstra real y no "dar
  siempre el paso que acerca en línea recta", que se atasca en cualquier
  esquina.
- **Atravesar aliados, pero no terminar encima de ellos**: en Descent, una
  figura puede *pasar a través* de casillas ocupadas por figuras aliadas al
  moverse — solo no puede *acabar* su movimiento ahí. Cripta lo implementa
  en `stepNeighbors(x, y, passFoes)` (`state.js`): con `passFoes=true`, los
  enemigos vivos no bloquean el paso, solo el terreno/objetos de verdad.
  `findApproachPath()` calcula así el camino MÁS CORTO real "como si los
  aliados no estuvieran" y lo recorta justo antes del primer aliado que
  encuentra de verdad — así, en un pasillo estrecho (recto o con esquinas),
  el enemigo se coloca en la mejor posición real posible (típicamente,
  justo detrás de su compañero) en vez de quedarse quieto sin más. Antes de
  esto, un enemigo bloqueado por otro en el único paso hacia el héroe se
  congelaba sin hacer nada (bug real, arreglado en v0.17/v0.18).
- **Huir rompiendo línea de visión, no solo maximizando distancia**: la
  condición "Terrified" de Descent hace que el monstruo termine su
  movimiento *fuera de la vista* del objetivo con prioridad sobre
  simplemente alejarse el máximo posible. `fleeStep()` en `rules.js` le da
  a esconderse detrás de una esquina un bonus de puntuación (+500) muy por
  encima de lo que puede aportar la distancia bruta, así que un arquero
  prefiere una casilla más cercana pero oculta a otra más lejana pero a la
  vista. Ojo con el efecto secundario que esto destapó: si el enemigo huye
  y queda sin línea de visión, la siguiente comprobación del propio turno
  ("lejos o sin visión: acercarse") deshacía la huida en el mismo turno —
  hay que recordar con una bandera (`fledThisTurn`) que ya ha huido este
  turno y no dejar que la lógica de "acercarse para recuperar visión" lo
  contradiga en la misma activación.

**Ideas que todavía NO están implementadas, por si hacen falta más adelante:**

- **Selección de objetivo por prioridad + desempate por distancia**: con
  varios héroes o aliados jugables, Road to Legend elige objetivo según una
  prioridad fija por tipo de monstruo (p.ej. "el que más daño ha recibido"),
  y solo si hay empate elige al más cercano. Útil el día que haya más de un
  personaje controlable.
- **Lista de acciones por prioridad, con "saltar si no aplica"**: cada tipo
  de monstruo en Road to Legend tiene una lista ordenada de acciones
  candidatas (atacar, usar habilidad, moverse...); se recorre de arriba a
  abajo, se salta lo que no se puede hacer, y se repite hasta agotar las
  acciones del turno. Es un árbol de comportamiento simple pero muy
  legible — podría ser una forma más mantenible de reescribir
  `meleeTurn`/`archerTurn`/`spectreTurn`/`mageTurn` como datos (una lista de
  reglas por tipo) en vez de código imperativo a medida, si el roster de
  enemigos crece mucho más.
- **"Blocked space" también bloquea línea de visión para el propio
  monstruo**: Descent distingue explícitamente cuándo un espacio bloquea
  movimiento, línea de visión, o ambos (muros bloquean los dos; figuras
  aliadas solo el movimiento para terminar ahí, no la línea de visión). Si
  Cripta añade más tipos de terreno especial, merece la pena mantener esa
  misma distinción explícita en vez de un único concepto de "bloqueado".

## Subir de versión

```
python3 tools/bump_version.py 0.9          # cambio grande
python3 tools/bump_version.py 0.8.2        # parche pequeño
```

Esto actualiza `VERSION`, `js/config.js` y todos los `?v=` del proyecto de
una sola vez. Después, a mano: escribe el contenido de `CHANGELOG.md` (dev)
y `data/changelog.json` (splash del juego, en es/en) para esa versión.

## Qué NO hacer sin comentarlo antes

- No añadir un bundler/build step (rompe el "sin build step" y complica
  Replit). Si algún día compensa por el tamaño del proyecto, coméntalo
  primero.
- No reestructurar carpetas de `js/` en subcarpetas mientras el proyecto sea
  de este tamaño (~2000 líneas): con 10 módulos de una sola responsabilidad
  cada uno, ya está razonablemente organizado.
- No asumir rutas absolutas ni nada específico de GitHub Pages (de cara a
  Capacitor/Electron más adelante).

## Guardado de partida (junto a la tienda de habilidades)

Desde la v0.20, cerrar la app a mitad de una mazmorra y volver a abrirla
**retoma exacto donde se dejó**: mismo nivel, posición, vida, PA restantes,
enemigos vivos/muertos, niebla explorada y el orden de combate en curso. Vive
en `js/savegame.js`, aparte de `state.js`/`rules.js` a propósito (mismo
espíritu que `skills.js`): guarda/restaura el estado por fuera, sin que el
motor necesite saber que existe un sistema de guardado.

**Qué se guarda y qué no:** todo lo DINÁMICO de `state` (héroe completo,
enemigos, triggers, salidas, niebla explorada, combate/targetFoe). Lo
ESTÁTICO de cada nivel (tiles, elevación, terreno difícil, `events.json`) NO
se guarda — se vuelve a cargar siempre desde `data/levels/<nivel>.json` y el
guardado se aplica ENCIMA. El inventario de equipo no se guarda aparte
porque, de momento, solo refleja el oro (no hay objetos de verdad todavía);
en cuanto haya equipo real habrá que añadirlo aquí.

**El oro es la única excepción**: vive en su propia clave (`cripta.gold`),
separada de la partida guardada (`cripta.save`), y es **un único número
compartido de verdad** entre la tienda de habilidades y `state.hero.gold` —
nunca dos bolsas distintas. Por eso sobrevive a un "Reiniciar partida" (que
sí borra la mazmorra en curso) y por eso lo que se gana o gasta dentro de la
mazmorra ya está disponible la próxima vez que se abre la tienda.

**Cuándo se guarda** (para que cerrar la app en cualquier momento pierda lo
mínimo posible): al cargar cualquier nivel, tras interactuar con un objeto,
al saltar turno, cada 3 segundos como red de seguridad (cubre turnos de la
IA y animaciones que no pasan por un clic directo), y al esconderse/cerrarse
la pestaña (`visibilitychange`/`beforeunload`). Limitación conocida: si se
guarda justo a mitad de una animación o de un turno de IA, el resume puede
no ser pixel-perfect en ese instante concreto (por ejemplo, un enemigo a
mitad de un desplazamiento) — no es grave, solo un pequeño salto visual, y
mejorar esto más no compensa mientras el sistema siga siendo temporal.

**"Reiniciar partida"** (botón de ajustes) y **"reiniciar progreso"** (botón
de la tienda de habilidades) hacen lo mismo con la mazmorra: la vuelven a
crear desde cero en el nivel 1 (mismo `newGame()` de `main.js`, enganchado a
la tienda con `bindFullReset`). La diferencia es el oro y las habilidades:
"Reiniciar partida" las conserva tal cual; "reiniciar progreso" también los
pone a cero (1000 de oro, ninguna habilidad).

## Efectos reales de las habilidades (V0.21)

Desde la v0.21, las 10 habilidades de la tienda **hacen de verdad lo que
dicen** en combate (antes eran solo catálogo/tienda, sin efecto real). Vive
repartido así:

- **`data/skills.json`**: cada tier trae un bloque `power` con los números
  reales (`critBonus`, `armorBonus`, `dodgeBonus`, `healChance`/`healPct`,
  `dmgPerKillPct`, `dmgMult`, `atkBuffPct`/`turns`...). Ya no son solo texto.
- **Pasivas de estadística plana** (Precisión carnicera→crítico, Piel de
  hierro→armadura, Reflejos felinos→esquiva): `skills.js` expone
  `getSkillBonuses()` y `applySkillBonuses(hero)`. Esta última se llama
  desde `main.js` cada vez que el héroe se (re)prepara — nivel nuevo, carry
  entre niveles, o partida retomada — y **siempre recalcula desde la base**
  (nunca suma sobre sí misma), así que es segura de llamar varias veces.
  `inventory.js` usa `getSkillBonuses()` para pintar en verde (`--moss`) la
  estadística que esté subida por una habilidad.
- **Pasivas de combate** (Golpes de fe, Sed de sangre) y los multiplicadores
  de las activas (Grito de guerra) viven en `rules.js` como estado de
  COMBATE en marcha (no de la tienda): `skillCooldowns`, `warCryTurnsLeft`/
  `warCryPct`, `bloodlustStacks`. Se resetean/decrementan en
  `checkCombatEnd()` (cooldowns bajan 1 combate; Sed de sangre vuelve a 0) y
  en `startHeroTurn()` (Grito de guerra decae 1 turno).
- **Habilidades activas**: `rules.js` exporta `useActiveSkill(id, gx, gy)`.
  `skills.js` gestiona el "armado" (tocar un icono de la barra de acción lo
  arma; el siguiente toque en el mapa dispara `tryUseArmedOnTile`, enganchado
  en `main.js` ANTES de `onTapTile` normal). Las de auto-lanzamiento
  (`range:0`, como Grito de guerra) se usan al toque, sin esperar objetivo.
  Como `rules.js` ya importaba cosas de `skills.js` (para leer tiers), la
  conexión inversa (skills.js -> rules.js) se hace con un **bind**
  (`bindUseActiveSkill`) para no crear un ciclo de imports.
- **Limitación a propósito**: de momento los efectos son daño/curación/buff
  INSTANTÁNEOS — no hay un motor de estados con turnos (quemadura, veneno
  que hace tic, ralentizado, aturdido de verdad). El texto de cada tier
  sigue describiendo la fantasía completa, pero mecánicamente hoy pega el
  golpe de una vez. Construir ese motor de estados-por-turno es el
  siguiente paso natural si hace falta más adelante.

## Victoria de toda la mazmorra, no de una zona suelta (V0.21)

Antes, limpiar los enemigos de CUALQUIER nivel (p.ej. los 2 esqueletos de
Mausoleo 1) disparaba la pantalla de victoria de toda la partida. Ahora
`rules.js` lleva la cuenta de bajas en `state.hero.totalKills` (viaja entre
niveles igual que la vida/el oro, vía `carry` en `descend()`), y la victoria
de verdad (`gameOver('win')`) solo salta cuando se iguala `totalFoeCount`
(la suma de enemigos de cementerio+cripta+mausoleo1+mausoleo2, calculada una
vez al arrancar en `main.js` y pasada con `setTotalFoeCount`). Limpiar un
tramo suelto solo cierra el combate de esa zona (`checkCombatEnd`), sin más.

## La tienda de habilidades (sistema TEMPORAL de pruebas)

Desde la v0.20 existe una pantalla ("Elige tus habilidades") que se abre justo
después de pulsar "Continuar" en las novedades, antes de entrar en la
partida. Vive entera en `js/skills.js` (datos + estado + render), a
propósito **desacoplada de `rules.js`**: de momento las habilidades no tienen
efecto real en combate, solo sirve para ir probando el catálogo (icono,
nombre, tipo de daño, activa/pasiva, duración, precio) e ir ajustando cada
una antes de que exista el sistema definitivo con sus efectos de verdad.
Cuando llegue ese sistema, esto se puede sustituir sin tocar el motor.

**Cómo está montado:**
- Catálogo en `data/skills.json`: cada habilidad tiene `id`, `icon` (ruta a
  `assets/ui/skills/<id>.png`), `kind` (`active`/`passive`), `damageType`,
  opcionalmente `class` (guerrero/paladín/...), `duration` (turnos del
  efecto) o `durationLabel` (clave i18n directa, para casos como
  "Permanente"/"Instantánea" que no son un número de turnos), y en las
  activas además `range` (casillas; `0`=uno mismo, `1`=cuerpo a cuerpo,
  `null`=no aplica), `area` (radio; `null`/`0`=objetivo único) y `cooldown`
  (en combates; `null`=sin enfriamiento). Un array `tiers` de 3 con el
  precio de cada uno. **`range`/`area`/`cooldown` son solo informativos por
  ahora** (no hay efectos reales en `rules.js` todavía). Los textos van en
  i18n: `skill.<id>.name`, `.desc`, `.tier1`/`.tier2`/`.tier3`.
- **3 tiers por habilidad**: al comprar un tier, la misma tarjeta pasa a
  ofrecer el siguiente (mismo hueco, no aparecen tarjetas nuevas). El precio
  sube por tier; se puede subir de tier cualquier habilidad en cualquier
  momento, sin requisitos entre ellas.
- **Iconos con fallback automático**: si `assets/ui/skills/<id>.png` no
  existe todavía, se ve un círculo con la inicial del nombre; en cuanto el
  archivo real se sube al proyecto, el `<img onerror>` dejar de disparar y
  se ve solo, sin tocar código. Los iconos reales que sube el usuario (arte
  Nano Banana, fondo magenta) se procesan igual que los sprites: quitar
  magenta por color, recortar al contenido real y guardar en
  `assets/ui/skills/<id>.png`.
- **Progreso persistente**: los tiers comprados en `localStorage`
  (`cripta.skills`), con su propio botón de "reiniciar progreso" dentro de
  la tienda (separado del "Reiniciar partida" de siempre; ver sección de
  guardado más arriba). El oro NO vive aquí — es el mismo `state.hero.gold`
  de siempre (ver sección de guardado).
- Al pulsar "Terminar" (con confirmación) se entra al juego, que ya estaba
  cargado en segundo plano desde el arranque (partida nueva o retomada).
- **Barra de acción de 10 huecos** (`#actionbar` en `index.html`), con los
  iconos de las habilidades ACTIVAS compradas, en el orden en que se
  compraron. Es un bloque más de `LAYOUT_IDS` en `main.js` (movible por
  separado con el reposicionador de interfaz de siempre).
- Las habilidades PASIVAS compradas se listan (nombre + tier en estrellas)
  en un grupo nuevo ("Habilidades") en la hoja de estadísticas del
  inventario (`js/inventory.js`), sin inventar un efecto numérico concreto
  todavía.
- El modal de confirmación genérico (`showConfirm`, `#confirmVeil`) se
  reutiliza aquí; por eso su z-index se subió a 25, por encima de la propia
  tienda (z-index 20), para que se vea encima al confirmar desde dentro.

## Emboscada sincronizada (V0.21.2) — los 2 sigilos de Mausoleo 2

Mausoleo 2 no tenía ningún enemigo colocado a mano — su única "amenaza" son
los 2 marcadores de evento del centro de la sala (`event_1`/`event_2`,
ahora renombrados), pensados como una emboscada: activar CUALQUIERA de los
dos hace aparecer 6 Espectros de golpe alrededor de ambos, en casillas
libres al azar.

**Cómo está montado (todo en `rules.js`, sección "Emboscada sincronizada"):**
- Nuevo tipo de trigger: `type: "ambush"`. Los 2 marcadores comparten el
  MISMO `id` (`mausoleo2_ambush`) — por eso basta una sola entrada en
  `events.json` para los dos, y sirve también para encontrar al "gemelo": al
  activar uno, `triggerAmbush()` busca todos los triggers `ambush` con ese
  mismo id y los marca `used` de golpe (el otro deja de poder tocarse y,
  como cualquier trigger no-cofre ya usado, deja de dibujarse).
- `spawnAmbushSpectres(origins, count=6, maxDist=3)` reutiliza
  `freeTilesNear()` (la misma función del Esqueleto Mago para invocar) desde
  CADA uno de los orígenes del grupo, junta las casillas candidatas sin
  repetir, las baraja (Fisher-Yates, dando algo de preferencia a las más
  cercanas por el orden de partida) y coloca ahí a los 6 Espectros
  (`sprite: 'enemy5'`, mismas stats que los de siempre: hp 16, atk 4).
  `freeTilesNear` ya descarta por sí sola la casilla del héroe, muros,
  otros enemigos y cualquier objeto/altar/marcador bloqueante — exactamente
  la condición pedida ("nunca encima de marcadores de evento, objetos,
  altares...").
- Los Espectros nacen ya despiertos (`dormant: false`): en cuanto se
  generan, `scanForNewCombatants()` los mete en la cola de iniciativa de
  inmediato y, si esto entra en combate por primera vez, se llama a
  `endHeroTurn(true)` — el mismo mecanismo de "despertar a mitad de camino"
  que ya existía para enemigos dormidos — así la emboscada de verdad
  interrumpe al héroe en vez de esperar a que acabe su turno.
- Carta de aviso en `events.json`/i18n (`ev.mausoleo2Ambush`): una sola
  opción ("Tocar el sigilo"), sin efecto de stats — el efecto real es la
  invocación, no algo que pase por `resolveChoice`.

## Contenedores de botín (V0.21.2) — primer paso del sistema de items

Los antiguos props tipo `item` ("Objeto" en el editor) pasan a ser
**contenedores de botín** genéricos: objetos repartidos por el mapa que
sueltan oro aleatorio, pensados como la base sobre la que en el futuro se
construirá el sistema de itemización completo (afijos, sufijos, únicos,
sets, palabras rúnicas — estilo Diablo 2). De momento **solo dan oro**, con
el mismo rango que los enemigos (10-200, subido temporalmente para probar
la tienda).

**Diferencia clave con el `chest`:** `chest` es el cofre narrativo especial
(ligado a una carta de `events.json`, y a futuro podrá llevar cerraduras,
trampas o checkeos de stats). `container` es el genérico y repetible, **sin
carta de evento** — se abre directo, como un cadáver. Cada uno tiene su
propio arte y su propio sonido — **no hay que confundirlos**:
- `chest` → arte de baúl de madera (`assets/props/chest/`), se abre con
  bisagra (clip `open`, 4 fotogramas), sonido `chestOpen`
  (`assets/audio/chestopen.mp3`).
- `container` → arte de jarrón de barro (`assets/props/container/`), se
  **rompe** en vez de abrirse (mismo clip `open` a nivel de código, pero
  visualmente es una secuencia de rotura: entero → agrietado → hecho
  pedazos → escombros), sonido `containerBreak`
  (`assets/audio/containerbreak.mp3`).

**Cómo está montado:**
- Tipo de prop nuevo: `container`, con su propio clip de animación en
  `anim.js` (`ANIM_CLIPS.container`: `idle` 1 fotograma, `open` 4
  fotogramas — el nombre de clip `open` es solo la etiqueta de código
  compartida con `chest`; el contenido real es la rotura del jarrón) y sus
  imágenes en `assets/props/container/idle.png` / `open.png` (arte de Nano
  Banana, magenta recortado agrupando por bandas horizontales —los
  fragmentos sueltos del jarrón roto quedan repartidos en varios
  componentes conectados independientes del cuerpo principal, así que se
  agrupan por su posición en la hoja en vez de por componente—, escala
  normalizada por el fotograma más alto del clip).
- El `chest` ya tenía su clip de animación reservado desde antes, pero
  nunca había llegado a conectarse a ningún nivel (los triggers `type:
  "chest"` no llevaban `sprite`, así que se veían con el icono ▪ genérico).
  Ahora los 3 cofres existentes (cementerio, cripta, mausoleo2/level2)
  llevan `"sprite": "chest"` y ya se ven con el baúl de madera real.
- En los niveles (`data/levels/*.json`), los triggers de contenedor ya no
  son `type: "item"` sino `type: "container"` y llevan `"sprite":
  "container"` para que `render.js` los pinte con el jarrón real en vez del
  icono ★ genérico de siempre.
- **Interacción** (`rules.js`, antes de entrar en el bloque genérico de
  objetos con carta): si el contenedor está adyacente, se reproduce la
  animación de saqueo del héroe + la rotura (`anim.openProp(...,
  'container')`) + el sonido `containerBreak` (solo la primera vez), se
  genera su botín una sola vez (`generateLoot()`, la misma función que usan
  los enemigos al morir — el parámetro `foe` no se usa, está reservado) y
  se abre la MISMA ventana de botín que un cadáver (`showLootWindow`). No
  cuesta PA, igual que recoger de un cadáver.
- El sonido `chestOpen` se dispara en `afterInteract` (rules.js), justo
  cuando el cofre narrativo se abre de verdad tras cerrar su carta.
- **Ventana de botín generalizada** (`ui.js`): antes solo la usaban
  cadáveres; ahora `showLootWindow(source)` distingue por
  `source.type === 'container'` para el título ("Contenedor" / i18n
  `loot.container`, en vez del nombre del enemigo) y para cómo desaparece al
  vaciarse: un cadáver pone `deathPlaying = false` (sistema de siempre); un
  contenedor pone `tr.used = true`, que ya hace que `render.js` deje de
  pintarlo (mismo criterio que cualquier otro prop de un solo uso) — así
  desaparece del mapa para siempre en cuanto se coge todo el botín.
- El manifest (`data/manifest.json`) tiene la clave `container` en vez de
  `item`, y ambos (`chest`/`container`) llevan ya su `sprite` de fábrica
  para que el editor de niveles (artifact aparte) lo asigne solo a
  cualquier cofre/contenedor nuevo que se coloque — pero el desplegable
  también debe actualizarse por su cuenta para mostrar "Contenedor" en vez
  de "Objeto"; lee el manifest en vivo, así que en cuanto esta versión esté
  publicada ya debería verlo solo.
- Se eliminó el evento suelto `item_1` de `events.json` (una tumba con 5 de
  oro/nada): ya no aplica, los contenedores no pasan por el sistema de
  cartas.

**Pendiente de verdad (fase 2, más adelante):** todo el sistema real de
itemización — rareza, afijos/sufijos, únicos, sets, palabras rúnicas, tablas
de drop por nivel — se construirá por partes, con preguntas concretas en
cada paso.

## Golem de hueso + arreglos varios + entrada/salida con arte real (V0.25)

**Golem de hueso** (nuevo enemigo, `sprite: 'golembone'`): monstruosidad
grande y lenta. Escala 1.5× la de un esqueleto normal — para esto hizo falta
un campo nuevo `tall` por ENEMIGO (antes solo el héroe tenía su propio
`HERO_TALL`; el resto de enemigos usaban siempre `TOKEN_TALL` fijo en
`render.js`). 90 hp / 9 atk / 4 PA.

**No aparece colocado en el mapa**: sale de una emboscada disparada al
activar el "Evento" que llevaba desde siempre sin enganchar en Mausoleo 1
(`event_1`, x:5 y:4 — ahora renombrado `mausoleo1_golem_guard`, tipo
`ambush`, con su propia carta en `events.json`/i18n). Al tocarlo aparecen
DE GOLPE el golem + 4 esqueletos normales (`enemy1`) alrededor, todos ya
despiertos, con la MISMA música de combate de élite que la emboscada de
espectros de Mausoleo 2 (`spawnGolemGuard()` en `rules.js`, generalizando
`triggerAmbush()` para poder elegir la composición según el `id` del
marcador — antes solo sabía invocar espectros). Como el resto de emboscadas
dinámicas (spectros de Mausoleo 2 incluidos), estos 5 enemigos NO cuentan
para el total de la mazmorra (`setTotalFoeCount`, que solo suma
`start.foes` de cada nivel) — es coherente con cómo ya se comportaba la
emboscada de Mausoleo 2, no es un bug nuevo.

Sus 2 habilidades se comprueban al EMPEZAR su turno (`golemTurn` en
`rules.js`), antes de la pelea cuerpo a cuerpo normal con el PA que quede:
1. **Rematar débiles** (prioridad si las dos se cumplen a la vez): si algo
   adyacente —el héroe o uno de sus propios compañeros esqueleto— tiene
   menos del 5% de su vida máxima, lo mata de un golpe (cuesta lo mismo que
   un ataque normal), se cura 25% de su propia vida máxima y su daño sube
   10% **para siempre** (no caduca — un monstruo que crece con cada
   víctima). Si remata a un aliado suyo, NO pasa por `killFoe()` (que
   registraría Sed de Sangre/Cosecha de Almas como si el HÉROE hubiera
   hecho la muerte) — usa `executeAllyFoe()`, una versión más ligera sin
   esos ganchos.
2. **Aturdir**: si tiene 2 o más unidades "del bando del héroe" adyacentes A
   LA VEZ, gasta 2 PA en aturdir a la que menos vida tenga durante 2 turnos
   DE ELLA (no del golem). Con solo 1 héroe y sin mascotas todavía esto casi
   nunca se cumple — se dejó construido a propósito para cuando existan
   mascotas de verdad (decisión tomada con el usuario).

**Aturdido, primer estado real del juego**: `hero.stunnedTurnsLeft`,
comprobado en `startHeroTurn()` — PA a 0, texto flotante "¡Aturdido!",
decrementa y pasa turno solo. El icono (`status_aturdido.png`) y el texto
i18n (`status.aturdido`) ya existían de antes, preparados para cuando
hiciera falta un sistema de estados real (ver limitación conocida en la
sección de habilidades V0.23) — esto es el primer estado que de verdad los
usa. Genérico por diseño (`stunTarget(target, turns)` acepta cualquier
combatiente), aunque hoy solo el héroe puede sufrirlo.

**Arte**: 4 hojas de sprite (idle 10 fotogramas, andar 7, ataque 8, muerte
8) recortadas a rejilla fija (sin huecos entre celdas, a diferencia de las
hojas del altar) y escaladas cada una a SU PROPIA referencia interna (el
fotograma más alto de ESE clip, nunca una escala compartida entre clips —
ver la lección ya anotada más abajo, en "Técnicas de arte y animación").
Nota conocida: 2 fotogramas del idle (7.º y 8.º) salieron con menos
contenido de lo esperado al recortar la rejilla — imperceptible en un bucle
de respiración tan sutil, pero retocable si se nota en el juego.

**Audio del golem**: 3 pistas propias (`golemboneidle/walk/death`), más un
sistema nuevo y genérico de "sonido ambiental de monstruo grande"
(`MONSTER_IDLE_SOUND` en `rules.js`, por sprite): si hay uno despierto a
menos de 4 casillas, suena su idle como mucho 1 vez cada 10s (cada uno con
su propio cronómetro). Ojo si se prueba en Node: el `setInterval` de este
sistema lleva `.unref()` condicional (`if (typeof t.unref === 'function')`)
para no dejar colgado un proceso de pruebas headless — no afecta al
navegador, donde ese método no existe.

**Música de combate de élite** (`ost_combatelite.mp3` → `combatelite.mp3`):
nueva pareja `audio.startEliteMusic()/stopEliteMusic()`, en bucle, baja (no
para del todo) el ambiente de bosque mientras suena. Arranca en la
emboscada sincronizada de espectros de Mausoleo 2 (`triggerAmbush`), para
sola al terminar el combate (`checkCombatEnd`). Reservada para cuando se
invoque al Esqueleto Mago en la Cripta (pendiente, no implementado aún).

**Entrada/salida con arte real**: el glifo ▮/▯ de siempre se sustituye por
una imagen de usuario (`assets/props/exit/model.png`, escaleras hacia la
oscuridad) en el bucle de `state.exits` de `render.js`. Detección
automática de "entrada grande": dos marcadores de salida en casillas
adyacentes (Chebyshev = 1) se dibujan como UN solo modelo centrado entre
las dos, al DOBLE de tamaño normal (decisión tomada con el usuario: doble
tamaño fijo, no ajustado al ancho de las 2 casillas). El aro/resplandor de
color de siempre (abierta/bloqueada, con niebla o sin ella) se queda
detrás del modelo, sin cambios.

**Habilidades bloqueadas en la barra de acciones**: velo rojo + número de
combates de enfriamiento restantes cuando una habilidad no se puede usar
(en CD o sin PA suficientes) — ya no se pueden pulsar. Nuevo getter
`getSkillCooldownLeft(id)` en `rules.js`, conectado a `skills.js` con el
mismo patrón bind-callback que ya usa `useActiveSkill` (`skills.js` no
puede importar `rules.js`: import circular). `renderActionBar()` ahora se
exporta y se refresca sola cada vez que se llama a `syncHUD()` (otro
bind-callback, `bindRefreshActionBar`, para que ui.js tampoco tenga que
importar skills.js).

**Arreglado — Golpe desde las Sombras atacaba/interactuaba "a distancia"**:
el teletransporte actualizaba `hero.x/hero.y` (posición lógica) pero nunca
el sprite en pantalla ni la cámara — el héroe ya estaba ahí de verdad, solo
que su dibujo se quedaba atrás. Nueva función `anim.snapTo(name, gx, gy)`
(reposiciona un actor de golpe, sin animación, incluso si ya existía —
a diferencia de `ensure()`, que no toca nada si el actor ya está creado).

**Reordenado — el contenedor se rompe al CERRAR el loot, no al abrirlo**:
`anim.openProp`/`audio.fx('containerBreak')` se movieron de la interacción
inicial (`rules.js`) a `markLootSourceEmptied()` (`ui.js`), que ya es el
único punto por el que pasa "este contenedor se ha vaciado del todo".

**Tienda de habilidades — ya no aparece al simple retomar una partida**:
antes se abría SIEMPRE al pulsar "Continuar" en la pantalla de novedades,
también al reanudar una partida guardada a medias. Ahora: `isFreshBoot`
(`!savegame.hasSave()` calculado ANTES de que `bootLevel()` decida nada) es
lo único que decide si "Continuar" abre la tienda; además `newGame()` (que
sirve tanto para morir-y-reintentar como para el botón manual de reiniciar)
y `descend()` (bajar de nivel) la abren siempre, sin depender de la
pantalla de novedades.

**Ajustes menores**: escala del altar +50% (`tall` propio, igual mecanismo
que el del golem); número de cantidad de oro en el inventario más grande en
móvil (14px→20px, negrita).

**Revisado y NO era un bug** — "abrir un cofre reinicia la partida": el
flujo completo (tarjeta → efecto → animación) no tiene ninguna ruta que
reinicie por error; si el cofre lleva el efecto negativo (`hp:-6`) y el
héroe ya estaba muy débil, sí puede morir de verdad, y la pantalla de
derrota (con su botón "jugar de nuevo") es justo eso: una muerte real, no
un reinicio accidental. Pendiente de confirmar con el usuario si le sigue
pasando con vida de sobra.

## Altares (V0.24)

Sistema nuevo, reemplaza al viejo evento genérico de 3 opciones que tenía el
altar desde el principio. **Un solo marcador genérico**: todos los altares
del juego son idénticos y comparten el mismo pool de 10 eventos aleatorios
(5 buenos / 5 malos) — no pasan por `events.json` en absoluto, el contenido
vive directamente en `ALTAR_EVENTS` (`rules.js`). Los 5 marcadores ya
colocados en los niveles (cementerio, cripta, level2, mausoleo1 ×2) se
reutilizaron tal cual, solo se les añadió `"sprite": "altar"` para que se
vean con el arte real en vez del rombo ◆ genérico.

**Flujo de interacción** (rama propia en `rules.js`, ANTES del bloque
genérico de "objeto con carta"):
1. Adyacente y sin gastar → `openAltarCard` (ui.js): tarjeta "story" con la
   imagen `altar_decision` y pregunta Sí/No (mismo patrón visual que
   `renderLeverCard`, pero con lógica propia — no es una palanca).
2. **Sí** → `resolveAltar(trig)` (conectado desde `main.js` a `rollAltar` en
   `rules.js`, vía `bindResolveAltar` — rules.js no se puede importar desde
   ui.js, ya que rules.js ya importa de ui.js: import circular). `rollAltar`
   sortea 1 de los 10, marca `tr.used = true`, aplica el efecto de verdad y
   devuelve la entrada elegida.
3. La MISMA tarjeta cambia a la imagen/texto de ESE evento concreto
   (`altar_evN` + `altar.evN.title`/`.result`), con sonido `altarGood`/
   `altarBad` según el tipo, y un botón **"Cerrar" explícito** (a diferencia
   de la palanca/ambientación, que se cierran tocando en cualquier parte —
   aquí se pidió expresamente un botón).
4. Al cerrar: `afterInteract` (rules.js) dispara `anim.pulseProp(...,
   'altar', 'activate'+N)` — enciende (fotogramas 1→4) y se apaga solo
   (4→1) en el propio mapa, y el altar queda para siempre en su idle de
   reposo (nunca se congela como el cofre, ni desaparece como un
   contenedor — por eso `render.js` tiene que exceptuar también a
   `type: 'altar'` de "se oculta en cuanto `tr.used`").
5. **No**, o altar ya gastado (toque posterior) → mensaje neutro
   (`log.altarSpent`), no pasa nada más.

**Arte**: 2 hojas de sprites subidas por el usuario (magenta, rejilla
4 columnas × 5 filas cada una) recortadas a fotogramas de 128×128 (mismo
`SPRITE_TILE` que el resto del juego) con chroma-key + reescalado
"contain" uniforme para las 40 celdas (evita que el altar cambie de
tamaño/posición entre eventos). `assets/props/altar/idle.png` (reposo,
compartido) + `activate1..10.png` (4 fotogramas cada uno). Las 11 imágenes
de ambientación (`altar_decision` + `altar_ev1..10`) son ilustraciones
completas del usuario, mismo molde que `story_lever_arm` (escena a la
izquierda, hueco de pergamino en blanco a la derecha) — convertidas a
`.jpg` (de ~29MB a ~4MB en total, sin transparencia real que perder).

**Los 10 eventos** (`ALTAR_EVENTS` en `rules.js`; `n` = nº de evento = sufijo
del clip `activateN` y de la imagen `altar_evN`):
- **Buenos** (rango 15%–40% donde aplica; buffs duran **3 combates**):
  1. Curación completa (a tope). 2. Lluvia de oro. 3. Bendición de fuerza
  (+15% daño hecho). 4. Piel de piedra (−15% daño recibido). 5. Ojo
  revelador (`revealAllExplored()` en state.js: marca todo el nivel como
  explorado/penumbra de golpe, no toca `visible`/iluminado).
- **Malos** (rango 5%–15%, suavizado a petición; debuffs duran
  **2 combates**): 6. Golpe del altar (quita vida, nunca deja al héroe a
  menos de 1). 7. Maldición de debilidad (−10% daño hecho). 8. Robo (quita
  oro, nunca negativo). 9. Invocación (1 enemigo cerca del altar,
  `freeTileAdjacentTo`, ponderado a la INVERSA de su vida máxima entre los
  3 tipos ya animados de verdad — esqueleto/arquero/espectro — cuanto más
  poderoso, menos probable, pero cualquiera puede salir). 10. Maldición de
  fragilidad (+10% daño recibido).

**Duración en combates, no en turnos**: los 4 buffs/debuffs
(`altarStrengthCombats`/`altarStonehideCombats`/`altarWeaknessCombats`/
`altarFragileCombats`) se decrementan en `checkCombatEnd()`, exactamente
igual que ya hacían los enfriamientos de habilidad (`skillCooldowns`) — NO
en `startHeroTurn()` como Grito de guerra/Forma Salvaje (esos sí son "por
turnos"). Se multiplican dentro de `resolveHeroHit` (daño hecho) y
`applyIncomingHit` (daño recibido, después de esquivar/bloquear, antes del
escudo de Gracia Vigilante).

**Pendiente/limitación conocida**: el pool de invocación solo incluye los
3 tipos de enemigo ya animados de verdad (esqueleto, arquero, espectro) —
el esqueleto mago (`enemy6`) se dejó fuera a propósito porque su lógica de
invocación (`spawnSkeleton`) asume que lo lanza OTRO mago, no tiene sentido
como aparición suelta. Cuando lleguen los otros 2 tipos de esqueleto
animados (ver pendientes generales más abajo), añadirlos aquí también.

**Pruebas hechas esta versión**: batería headless propia (`rollAltar`
invocado miles de veces con `state` simulado) comprobando que los 10
eventos salen con frecuencia pareja, que los rangos de daño/oro/curación
respetan sus límites (incluida vida a 1 / oro a 0), que Invocación coloca
al enemigo adyacente al altar ya despierto, y que llamar `rollAltar` dos
veces sobre el mismo trigger no revienta. Los niveles tocados solo
recibieron el campo `sprite` añadido (ninguna casilla/posición cambió), así
que no hacía falta repetir el test de conectividad completo.

## Efectos reales de las 11 habilidades nuevas (V0.23)

Se añaden 11 habilidades más de 7 clases nuevas (Asesino, Mago, Brujo,
Clérigo, Druida, Nigromante, Cazador), todas con efecto real en combate
desde el minuto uno (mismo criterio que las 10 de la V0.21 — nada de
catálogo-sin-efecto). Aparcadas a propósito (ver "Pendiente" más abajo):
**Levantar Muertos** y **Vínculo con la Fiera** (necesitan aliados/mascota
controlados por IA propia) y **Maldición Persistente** (necesitaría un
motor de estados-por-turno real que hoy no existe).

- **Golpe desde las Sombras** (Asesino, activa): teletransporta al héroe a
  una casilla libre junto al objetivo (`freeTileAdjacentTo`) y golpea con
  más probabilidad de crítico. Tier 3 = crítico garantizado, pero solo
  **una vez por combate** (`shadowStrikeUsedThisCombat`, se resetea en
  `checkCombatEnd`). Nota: el tier 2 no puede "ignorar armadura" porque los
  enemigos no tienen armadura propia en este motor — se convirtió en un
  pequeño bonus de daño en su lugar.
- **Instinto Letal** (Asesino, pasiva): bonus de daño si el objetivo está
  por debajo del % de vida de su tier. Se aplica dentro de `resolveHeroHit`
  a CUALQUIER golpe del héroe (normal o activa), no solo a una habilidad.
- **Cadena Arcana** (Mago, activa): golpea al objetivo y salta al enemigo
  vivo más cercano (dentro de `jumpRange`) sin repetir, perdiendo `falloffPct`
  de daño en cada salto, hasta `jumps` veces.
- **Sobrecarga Arcana** (Mago, pasiva): al usar CUALQUIER activa, tira su
  probabilidad de no gastar el enfriamiento (`finishActiveSkillUse`). Tier 3
  cura un poco si son 2 procs seguidos (`arcaneOverloadStreak`).
- **Pacto de Sangre** (Brujo, activa): descuenta un % de la vida ACTUAL del
  héroe (nunca lo deja a 0, mínimo 1) e inflige daño de sombra alto; tier 3
  roba parte de ese daño como vida si el golpe mata.
- **Círculo de Renacer** (Clérigo, activa, auto-lanzamiento): cura al
  instante y, desde tier 2, deja una zona en el suelo (`holyZones`, radio
  `area`) que sigue curando cada turno del héroe mientras esté dentro y
  dura lo que indique `durationTurns`. Tier 3 añade `preventLethalOnce`: un
  golpe que dejaría al héroe a 0 lo deja en 1 en su lugar, una sola vez por
  zona lanzada (comprobado en `applyIncomingHit` → `tryLethalWard`).
- **Gracia Vigilante** (Clérigo, pasiva): `hero.wardShield` se PONE (no se
  suma) a `shieldPct × maxHp` al empezar cada turno del héroe
  (`refreshWardShield`), y absorbe daño antes que la vida en
  `applyIncomingHit`. Tier 3 cura un poco si el escudo del turno anterior
  seguía en pie al refrescarlo.
- **Forma Salvaje** (Druida, activa, auto-lanzamiento): buff temporal por
  turnos (mismo patrón que Grito de guerra: `wildShapeTurnsLeft`, decrece en
  `startHeroTurn`) con bonus de daño, armadura y curación al golpear. Se
  quitó la "penalización a distancia" del diseño original: el héroe no tiene
  una probabilidad de acierto a distancia que penalizar en este motor, así
  que el texto del tier 1 se simplificó para no prometer algo que no pasa.
- **Simbiosis Natural** (Druida, pasiva): `damageTakenLastTurn` se acumula en
  `applyIncomingHit` (por tanto solo cuenta golpes de combate, no trampas) y
  se revisa en `startHeroTurn` para curar si el turno anterior fue limpio (o
  de poco daño, desde tier 2). Tier 3 añade armadura mientras esté a vida
  completa.
- **Cosecha de Almas** (Nigromante, pasiva): misma mecánica que Sed de
  sangre (racha que se resetea al acabar el combate) pero solo cuenta
  muertes dentro de `nearbyRange` del héroe, y se aplica como multiplicador
  GENERAL de daño (no solo a hechizos de sombra) para que no sea una pasiva
  muerta mientras el héroe no tenga más hechizos de esa escuela. Tier 3: a 5
  stacks, el próximo uso de cualquier activa no gasta enfriamiento (comparte
  el mismo "vale" que Sobrecarga Arcana, `freeNextCastSkip`).
- **Disparo Múltiple** (Cazador, activa): traza una línea recta de 8
  direcciones desde el héroe hacia la casilla tocada (`foesInLine`, se para
  en el primer muro) y golpea a los primeros `maxTargets` enemigos que
  encuentra. Tier 3 añade `slowedTurns`: el enemigo afectado actúa con 1 PA
  menos en su PRÓXIMO turno, sea cual sea su tipo de IA (se resta y se
  restaura en el único punto común de las 4 variantes de turno enemigo,
  `runSingleFoeTurn`, sin tocar cada una por separado).

**Limitación conocida** (igual que ya advertía la V0.21): sigue sin existir
un motor de estados-por-turno de verdad. Todo lo de arriba son
turnos-contados a mano (como ya hacía Grito de guerra), no un sistema
genérico de "efectos con duración" reutilizable — construir ESE sistema es
lo que de verdad haría falta para Maldición Persistente (y para que
Tajo llameante/Nube de veneno quemen o envenenen de verdad turno a turno,
en vez de golpear una sola vez).



**Lección de la 0.20.1**: entre la 0.18 y la 0.19 se colaron dos regresiones
en `cemetery.json` (se perdió `background:{key:bg_cemetery}` y un evento
junto a la entrada perdió su `walkTrigger:true`, además de cambiar de id sin
querer y quedar desconectado de `events.json`). Ninguna se detectó a tiempo
porque la batería de pruebas headless no comprueba fondos pintados ni el
contenido de `events.json` contra los triggers de cada nivel — solo
conectividad/solapes. Si se retoca `cemetery.json` (o cualquier nivel con
fondo pintado) en el futuro, comprobar a mano estos dos puntos antes de dar
la versión por buena: 1) `background` sigue apuntando a una clave real de
`assets.js`; 2) cada trigger con `walkTrigger` en la versión anterior lo
sigue teniendo, y su `id` sigue coincidiendo con la clave real en
`events.json` (no basta con que el juego no reviente — puede fallar en
silencio mostrando el mensaje neutro de "sin evento conectado" en vez del
contenido real).

Ver `CHANGELOG.md` y `data/changelog.json` para el historial completo. A
grandes rasgos, sigue pendiente:
- **Las 4 salidas del cementerio grande ya están conectadas**: 1 y 2 llevan
  a `cripta` (siempre abiertas), 3 a `mausoleo1` y 4 a `mausoleo2`, ambas
  bloqueadas hasta tirar de `lever_1` (adyacente). El motor ahora soporta
  **varias salidas por nivel** (`state.exits`, cada una "mueble": ocupa su
  casilla, se interactúa desde al lado, opcionalmente `blocked`) además del
  formato antiguo de una sola (`state.exit`, sigue igual para Cripta,
  Mausoleo1, Mausoleo2 y level2 — no hacía falta tocarlos). La carta de la
  palanca sigue el patrón "pregunta Sí/No → la misma tarjeta cambia a texto
  de resultado" (`ev.<id>.question` / `.result` en events.json, con
  `unlocks: [ids de salidas]`) — reutilizable para futuras palancas sin
  tocar el motor, solo añadiendo la entrada en `events.json` + i18n.
- Enganchar `cast`/`potion` (héroe y esqueleto) a algún efecto de juego real.
- **Aparcadas a propósito tras la V0.23** (mismo calibre de trabajo, mejor
  todas juntas cuando toque): **Levantar Muertos** (Nigromante, necesita
  aliados invocados con IA propia, distinta del héroe y del enemigo — tocaría
  bastante `rules.js`/`state.js`), **Vínculo con la Fiera** (Cazador, necesita
  un sistema de mascota controlable que hoy no existe), y **Maldición
  Persistente** (Brujo, necesitaría el motor de estados-por-turno real
  mencionado arriba, que hoy tampoco existe).
- Animar a los otros dos tipos de esqueleto (espada+escudo, con armadura)
  cuando lleguen sus sprites — hoy están desactivados en el manifiesto.
- Usar el ensamblador de losetas (`mapgen.js`) para un nivel aleatorio.
- Sacar iconos sueltos del pool de UI estilo Diablo que el usuario subió
  (Claude guarda una copia de referencia fuera del repo; el pool en sí no
  vive en el proyecto para no hincharlo — pedir a Claude si hace falta algo
  de ahí).
