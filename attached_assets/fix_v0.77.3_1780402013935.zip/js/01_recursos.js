// ============================================================
// BLOQUE JS-01 — RECURSOS (rutas a imágenes y audio)
// El objeto ASSETS mapea nombres lógicos a rutas físicas dentro
//   de la carpeta assets/. Para reemplazar una imagen o el audio,
//   sustituir el archivo correspondiente en assets/images o
//   assets/audio manteniendo el nombre.
// ============================================================

// Versión actual del juego. ACTUALIZAR EN CADA ENTREGA.
// Se muestra en el panel de depuración (Ctrl+D / tap arriba-izquierda).
const JUEGO_VERSION = "0.77.3";
window.JUEGO_VERSION = JUEGO_VERSION;

// ------------------------------------------------------------
// BLOQUEO DE ORIENTACIÓN (vertical).
// Intento "best effort": donde el navegador lo soporte, fijamos la
// orientación a vertical. Donde no (iOS Safari y la mayoría de navegadores
// móviles fuera de pantalla completa), no pasa nada: el overlay CSS
// (#rotacion-overlay) se encarga de pedir girar el dispositivo. Se
// envuelve en try/catch porque lock() rechaza con error si no se cumple
// la condición de pantalla completa, y no queremos que eso ensucie nada.
// ------------------------------------------------------------
(function intentarBloquearVertical(){
  try{
    // Solo tiene sentido en dispositivos táctiles (móvil/tablet). En PC
    // no se intenta siquiera: el ratón no rota la pantalla.
    var esTactil = window.matchMedia && window.matchMedia('(pointer: coarse)').matches;
    if(!esTactil) return;
    if(screen && screen.orientation && typeof screen.orientation.lock === 'function'){
      const p = screen.orientation.lock('portrait');
      if(p && typeof p.catch === 'function') p.catch(function(){ /* no soportado: lo cubre el overlay */ });
    }
  }catch(e){ /* silencioso: el overlay CSS es el plan de respaldo */ }
})();

const ASSETS = {
  APPROACH_SECTOR7: "assets/images/approach_sector7.webp",
  ARRIVAL_SECTOR7: "assets/images/arrival_sector7.webp",
  DOCK_ACCESS_TUNNEL: "assets/images/dock_access_tunnel.webp",
  ENERGY_DISPATCH_CENTER: "assets/images/energy_dispatch_center.webp",
  FREE_TRANSIT_HUB: "assets/images/free_transit_hub.webp",
  FREIGHT_HUB07: "assets/images/freight_hub07.webp",
  HELIX_MEDICAL_CENTER: "assets/images/helix_medical_center.webp",
  HELIX_MEDICAL_WING: "assets/images/helix_medical_wing.webp",
  HOUSING_BLOCK_B2: "assets/images/housing_block_b2.webp",
  INDUSTRIAL_WALKWAY9: "assets/images/industrial_walkway9.webp",
  LOWER_CANAL_SECTOR7B: "assets/images/lower_canal_sector7b.webp",
  MAPA_STRATA: "assets/images/mapa_strata.webp",
  MAPA_STRATA_PC: "assets/images/mapa_strata_pc.webp",
  MAINTENANCE_ACCESS12: "assets/images/maintenance_access12.webp",
  MARA_ALLEY_CLEAN: "assets/images/mara_alley_clean.webp",
  MARKET_DISTRICT_TIER1: "assets/images/market_district_tier1.webp",
  PORT_AUTHORITY_SECTOR3A: "assets/images/port_authority_sector3a.webp",
  SECTOR7_BLACK_MARKET: "assets/images/sector7_black_market.webp",
  SECTOR7_CENTRAL_PLAZA: "assets/images/sector7_central_plaza.webp",
  SECTOR7_STREETS: "assets/images/sector7_streets.webp",
  SERVICE_CONDUIT_RAMP_E: "assets/images/service_conduit_ramp_e.webp",
  SOUTH_ELEVATOR_LEVEL4: "assets/images/south_elevator_level4.webp",
  SURGERY_ROOMS_CORRIDOR: "assets/images/surgery_rooms_corridor.webp",
  SURGICAL_SUITE: "assets/images/surgical_suite.webp",
  TREATMENT_WING: "assets/images/treatment_wing.webp",
  WEST_CORRIDOR_LOCKER218: "assets/images/west_corridor_locker218.webp",
  APT: "assets/images/apt.jpg",
  PASILLO: "assets/images/pasillo.jpg",
  MERCADO: "assets/images/mercado.jpg",
  BAR: "assets/images/bar.jpg",
  MARA: "assets/images/mara.jpg",
  CERO: "assets/images/cero.jpg",
  TREN: "assets/images/tren.jpg",
  BOOT: "assets/images/boot.jpg",
  ESPACIO: "assets/images/espacio.jpg",
  AUDIO: "assets/audio/audio.mp3",
  MAIN_THEME: "assets/audio/main_theme.ogg",
  ASHES_OF_HELIX: "assets/audio/ashes_of_helix.ogg",
  INTRO_THEME: "assets/audio/intro_theme.mp3",
  FERRO_TRANSITO_1: "assets/images/ferro_transito_1.webp",
  FERRO_TRANSITO_2: "assets/images/ferro_transito_2.webp",
  FERRO_TRANSITO_3: "assets/images/ferro_transito_3.webp",
  FERRO_ZONA: "assets/images/ferro_zona.webp",
  CARMESI_TRANSITO_1: "assets/images/carmesi_transito_1.webp",
  CARMESI_TRANSITO_2: "assets/images/carmesi_transito_2.webp",
  CARMESI_TRANSITO_3: "assets/images/carmesi_transito_3.webp",
  CARMESI_ZONA: "assets/images/carmesi_zona.webp",
  SANTUARIO_TRANSITO_1: "assets/images/santuario_transito_1.webp",
  SANTUARIO_TRANSITO_2: "assets/images/santuario_transito_2.webp",
  SANTUARIO_TRANSITO_3: "assets/images/santuario_transito_3.webp",
  SANTUARIO_ZONA: "assets/images/santuario_zona.webp",
  NODO_TRANSITO_1: "assets/images/nodo_transito_1.webp",
  NODO_TRANSITO_2: "assets/images/nodo_transito_2.webp",
  NODO_TRANSITO_3: "assets/images/nodo_transito_3.webp",
  NODO_ZONA: "assets/images/nodo_zona.webp",
  EXP_ALMACEN_HELIX: "assets/images/exp_almacen_helix.webp",
  EXP_PUERTO_ORBITAL_1: "assets/images/exp_puerto_orbital_1.webp",
  EXP_TALLER_PROTESIS_1: "assets/images/exp_taller_protesis_1.webp",
  EXP_MERCADO_OLVIDADOS: "assets/images/exp_mercado_olvidados.webp",
  EXP_GUARIDA_ECO: "assets/images/exp_guarida_eco.webp",
  EXP_PLANTA_AGUA: "assets/images/exp_planta_agua.webp",
  EXP_MERCADO_SUMERGIDO: "assets/images/exp_mercado_sumergido.webp",
  EXP_TALLER_REUTILIZA: "assets/images/exp_taller_reutiliza.webp",
  EXP_CALLEJON_NIVELES: "assets/images/exp_callejon_niveles.webp",
  EXP_CIBERCAFE: "assets/images/exp_cibercafe.webp",
  EXP_TALLER_NEURAL: "assets/images/exp_taller_neural.webp",
  EXP_ALMACEN_OKUPA: "assets/images/exp_almacen_okupa.webp",
  EXP_CANAL_PILAS: "assets/images/exp_canal_pilas.webp",
  EXP_COMEDOR_SECTORB: "assets/images/exp_comedor_sectorb.webp",
  EXP_SANTUARIO_ECO: "assets/images/exp_santuario_eco.webp",
  EXP_CALLEJON_SUENOS: "assets/images/exp_callejon_suenos.webp",
  EXP_PUERTO_ORBITAL_2: "assets/images/exp_puerto_orbital_2.webp",
  EXP_PUERTO_CARGA: "assets/images/exp_puerto_carga.webp",
  EXP_PLAZA_OLVIDADOS: "assets/images/exp_plaza_olvidados.webp",
  EXP_ALMACEN_ZONA7: "assets/images/exp_almacen_zona7.webp",
  // --- Intro cinemática (17 frames, v0.73.2) ---
  INTRO_01: "assets/images/intro_01.jpg",
  INTRO_02: "assets/images/intro_02.jpg",
  INTRO_03: "assets/images/intro_03.jpg",
  INTRO_04: "assets/images/intro_04.jpg",
  INTRO_05: "assets/images/intro_05.jpg",
  INTRO_06: "assets/images/intro_06.jpg",
  INTRO_07: "assets/images/intro_07.jpg",
  INTRO_08: "assets/images/intro_08.jpg",
  INTRO_09: "assets/images/intro_09.jpg",
  INTRO_10: "assets/images/intro_10.jpg",
  INTRO_11: "assets/images/intro_11.jpg",
  INTRO_12: "assets/images/intro_12.jpg",
  INTRO_13: "assets/images/intro_13.jpg",
  INTRO_14: "assets/images/intro_14.jpg",
  INTRO_15: "assets/images/intro_15.jpg",
  INTRO_16: "assets/images/intro_16.jpg",
  INTRO_LOGO: "assets/images/intro_17.jpg"
};

// Apply backgrounds

// ============================================================