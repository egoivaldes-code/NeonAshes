# NEON ASHES — PROJECT BLUEPRINT

Este paquete contiene:
- Filosofía creativa
- Dirección narrativa
- Reglas de tono
- Arquitectura recomendada
- Documentación contextual para IA
- Organización modular sugerida

Objetivo:
Convertir NEON ASHES en un proyecto sostenible, coherente y fácil de expandir
con ayuda de IA sin perder identidad artística.

## Estructura recomendada

NeonAshes/
├── index.html
├── css/
├── js/
├── assets/
├── docs/
└── saves/

## Filosofía principal

El proyecto prioriza:
- atmósfera
- melancolía
- inmersión
- humanidad
- narrativa
- subtexto
- consecuencias

Evitar:
- UI arcade
- power fantasy
- loot RPG
- exceso de sistemas
- humor Marvel
- cyberpunk caricaturesco
