# NEON ASHES — VISIÓN

NEON ASHES no es un power fantasy.

El jugador:
- no es especial
- no es un elegido
- no empieza siendo poderoso

El jugador es:
una persona normal intentando sobrevivir dentro de una civilización corporativa decadente.

## Objetivo emocional

El juego debe generar:
- melancolía
- soledad
- intimidad
- memoria emocional
- cansancio existencial
- sensación de humanidad erosionada

## Filosofía de diseño

Priorizar:
- inmersión
- atmósfera
- narrativa
- ritmo lento
- decisiones humanas
- consecuencias persistentes

Evitar:
- loops adictivos
- power creep
- sistemas inflados
- grindeo
- UI sobrecargada

## Experiencia objetivo

El jugador debe sentir:
- que sobrevive
- que trabaja
- que envejece
- que recuerda
- que se adapta
- que la ciudad sigue aunque él desaparezca
