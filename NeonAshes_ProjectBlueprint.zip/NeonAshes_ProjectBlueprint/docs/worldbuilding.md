# WORLDBUILDING

## Estado de la humanidad

La humanidad ha colonizado:
- el sistema solar
- estaciones orbitales
- colonias lejanas
- Alpha Centauri

El espacio profundo sigue siendo desconocido.

## HELIX INDUSTRIES

HELIX controla:
- medicina
- implantes
- seguridad
- comunicación
- transporte
- infraestructura

HELIX no es puramente malvada.

Es:
- indispensable
- eficiente
- monstruosa
- sistémica

## Lower Stacks

Megabloques brutalistas:
- lluvia ácida
- hacinamiento
- neones dañados
- ruido industrial
- anuncios persistentes

El mundo debe sentirse vertical y opresivo.

## Tecnología

La tecnología:
- funciona
- pero está degradada
- parcheada
- reutilizada

Nada debe sentirse limpio o perfecto.
