# DIALOGUE SYSTEM

## Objetivo

Las conversaciones deben:
- revelar carácter
- generar tensión
- construir memoria

## Reglas

- frases cortas
- silencios importantes
- evitar tutorialización

## IA

La IA narrativa debe:
- recordar tono
- recordar relaciones
- reaccionar al historial
