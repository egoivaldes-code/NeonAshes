# TIME SYSTEM

## Función

El tiempo no es decoración.

Debe:
- afectar percepción
- generar rutina
- sostener inmersión

## Ejemplos

- alquiler diario
- desgaste humano
- cansancio
- horarios
- ciclos ambientales

## Filosofía

El jugador debe sentir:
que la ciudad sigue funcionando aunque él no haga nada.
