# ECONOMY SYSTEM

## Objetivo emocional

La economía debe generar:
- presión constante
- ansiedad suave
- desgaste psicológico

## Filosofía

El dinero:
- mantiene vivo
- no hace poderoso

## Sistemas compatibles

- alquiler
- recibos
- deuda
- trabajos pequeños
- pagos irregulares

## Evitar

- inflación de recompensas
- loot explosivo
- progresión absurda
