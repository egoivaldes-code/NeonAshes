# TONO

## Referencias emocionales

Inspiraciones:
- Blade Runner
- Disco Elysium
- Citizen Sleeper
- Ghost in the Shell
- Arrival
- The Expanse

Nunca copiar directamente.

## Tono general

El mundo debe sentirse:
- usado
- cansado
- húmedo
- silencioso
- humano
- decadente
- íntimo

## Diálogo

Los personajes:
- no explican demasiado
- insinúan
- evitan vulnerabilidad explícita
- usan subtexto

Evitar:
- exposición artificial
- monólogos largos
- sarcasmo constante
- humor Marvel
- edge adolescente

## Ritmo

El juego necesita:
- pausas
- silencios
- respiración
- contemplación

No convertir la experiencia en acción continua.
