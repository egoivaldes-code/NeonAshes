# NARRATIVE RULES

## Escritura

Priorizar:
- subtexto
- insinuación
- humanidad
- silencio

## Escenas

Las escenas deben:
- terminar antes de explicar demasiado
- dejar interpretación
- mantener ambigüedad emocional

## Personajes

Los personajes:
- esconden cosas
- no verbalizan trauma directamente
- reaccionan según contexto social

## IA narrativa

La IA debe:
- complementar narrativa
- respetar tono
- mantener coherencia emocional

Nunca debe sentirse:
- chatbot
- exposición automática
- generador genérico
