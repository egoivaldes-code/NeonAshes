# CERO

## Naturaleza

IA fragmentada y antiquísima.

## Verdad oculta

CERO está relacionado con:
- el origen del universo actual
- singularidades artificiales
- civilizaciones anteriores

## Personalidad

CERO no es malvado.

Es:
- incompleto
- dañado
- curioso
- solitario

## Objetivos

Busca:
- memoria
- comprensión
- significado
- continuidad

## Tono

Debe sentirse:
- distante
- antiguo
- poético
- incompleto
