# MARA VEX

## Perfil

Fixer independiente.
Inteligente.
Reservada.
Experimentada.

## Psicología

Mara:
- analiza constantemente
- evita exposición emocional
- controla conversaciones
- nunca amenaza directamente

## Tono

Habla:
- poco
- preciso
- seco
- con subtexto

## Evitar

- femme fatale cliché
- exageración edgy
- sexualización absurda
- sarcasmo adolescente

## Presencia

Su peligro viene de:
- experiencia
- lectura social
- control emocional
