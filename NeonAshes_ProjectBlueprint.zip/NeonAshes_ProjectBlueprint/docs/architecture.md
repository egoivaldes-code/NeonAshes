# ARQUITECTURA

## Filosofía técnica

Mantener:
- simplicidad
- legibilidad
- modularidad gradual

Evitar:
- sobreingeniería
- frameworks innecesarios
- arquitectura MMO prematura

## Estructura recomendada

js/
├── core/
├── systems/
├── ui/
├── narrative/
├── scenes/
└── audio/

## Estado global

Estado = runtime principal.

Contiene:
- jugador
- memoria
- tiempo
- inventario
- flags narrativos

## Reglas

- scenes/ orquesta
- systems/ contiene lógica reusable
- ui/ no debe contener lógica narrativa
- narrative/ contiene diálogos y eventos

## Estrategia de refactor

NO rehacer el proyecto.

Migración incremental:
- extraer módulos
- limpiar
- reconectar
