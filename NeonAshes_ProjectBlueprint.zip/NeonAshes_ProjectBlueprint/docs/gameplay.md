# GAMEPLAY

## Prioridades

El gameplay debe priorizar:
- exploración
- conversación
- supervivencia
- observación
- consecuencias

## NO priorizar

- combate constante
- loot
- power scaling
- RPG numérico exagerado

## Economía

La economía debe generar:
- ansiedad cotidiana
- desgaste
- presión suave

No debe sentirse como:
- casino
- MMO
- idle game

## Tiempo

El tiempo diegético es importante.

Debe:
- avanzar
- generar rutina
- afectar percepción emocional

## Muerte

La muerte debe sentirse:
- silenciosa
- fría
- inevitable
- humana

La ciudad continúa aunque el jugador desaparezca.
