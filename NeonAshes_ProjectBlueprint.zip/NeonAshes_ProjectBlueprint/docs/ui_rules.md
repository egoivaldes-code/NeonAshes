# UI RULES

## Filosofía visual

La UI debe sentirse:
- diegética
- industrial
- usada
- minimalista

## Evitar

- HUDs gigantes
- minimapas invasivos
- colores de rareza
- overlays MMO
- interfaces arcade

## Estética

Colores:
- cyan apagado
- magenta tenue
- grises fríos
- negro azulado

## Animación

Las animaciones deben:
- ser lentas
- suaves
- discretas

Nada debe sentirse “gamificado”.
