# FACTIONS

## HELIX INDUSTRIES

Megacorporación dominante.
Mantiene infraestructura civilizatoria.

## Contrabandistas

Redes informales:
- logística
- información
- supervivencia

## Seguridad privada

Fragmentada.
Violenta.
Más corporativa que estatal.

## Habitantes de Lower Stacks

Sobreviven mediante:
- microtrabajos
- deuda
- favores
- mercado gris
